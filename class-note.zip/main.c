#include <stdio.h>
#include <stdlib.h>
#include <math.h>
int main (void)
{
char fn_str[255];
char sn_str[255];
float fn ;
float sn ;
float result ;
printf ("Input first number : ") ;
scanf ("%s", fn_str) ;
fn = atof(fn_str) ;
printf ("Input second number : ") ;
scanf ("%s", sn_str) ;
sn = atof(sn_str) ;
if ((fmodf(fn,2) == 0) && (fmodf(sn,2) == 0))
{
result = fn + sn ;
printf ("both even : %0.2f\n", result) ;
}
if ((fmodf(fn,2) != 0) && (fmodf(sn,2) != 0))
{
result = fn * sn ;
printf ("both odd : %0.2f\n", result) ;
}
if (((fmodf(fn,2) != 0) && (fmodf(sn,2) == 0)) ||
((fmodf(fn,2) == 0) && (fmodf(sn,2) != 0)))
{
result = fn - sn ;
printf ("different : %0.2f\n", result) ;
}
}