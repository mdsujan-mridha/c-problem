

#include <stdio.h>

int main()
{
    int a;
    
    printf("Enter the number:");
    scanf("%d",&a);
    
    if(a%2==0){
     printf("The number is divisile by 2\n");
    }
     else if(a%5==0){
        printf("The number is divisible by 5\n ");    
    }
     else {
     printf("The number is error\n");
     }
    return 0;
}
