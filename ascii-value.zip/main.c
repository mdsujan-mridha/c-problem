#include<stdio.h>
int
main ()
{
  char lower;
  printf ("Enter your lower case later:");
  scanf ("%c",&lower);
  printf ("The upercase later is: %c",lower-32);
  return 0;

}
