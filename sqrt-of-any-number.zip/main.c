#include<stdio.h>
#include<math.h>
int main()
{
    double x;
    printf("Enter your Number:");
    scanf("%lf",&x);
    x=sqrt(x);
    printf("The root is:%.2lf",x);
}