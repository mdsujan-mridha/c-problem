#include<stdio.h>
int main()
{
    float cm , m, km;
    printf("Enter Your  cm number:");
    scanf("%f",&cm);
   m=cm/100.0;
   km=cm/1000.0;
    printf("The  cm number into meter is:%.2f\n",m);
     printf("The  cm number into km is:%.2f\n",km);
    return 0;
}