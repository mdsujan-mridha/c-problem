#include<stdio.h>
  int main()
        {
            double maths[4][5];
            int c,r;
            for(c=0;c<4;c++)
            {
                for(r=0;r<5;r++)
                {
                    scanf("%lf",&maths[c][r]);
                }
            }
            
               for(c=0;c<4;c++)
            {
                for(r=0;r<5;r++)
                {
                    printf("Class%d,Roll%d, Marks%lf\n", c+6, r,maths[c][r]);
                }
            }
            
           return 0; 
            
             
        }