#include<stdio.h>
int main()
{
    int number;
    printf("Enter Your decemil Number=");
    scanf("%d",&number);
    printf("Your Octal number is= %o",number);
    getch();
    return 0;
    
}