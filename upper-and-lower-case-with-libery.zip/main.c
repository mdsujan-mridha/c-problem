#include<stdio.h>
 int main()
    {
        char lower,upper;
        printf("Enter your lowercae latter :");
        scanf("%c",&lower);
        upper=toupper(lower);
        printf("Upercase Later is: %c",upper);
        return 0;
    }