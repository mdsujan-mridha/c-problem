#include<stdio.h>
int main ()
{
  int x, y, z;

  printf ("Enter two number:");
  scanf ("%d%d", &x, &y);

  if (x%2&&x%2==0, y%2&&y%5==0)
    {
      printf("The number is even");
      
      z = x + y;
    printf("The sum is:%d\n",z);

    }
    
  else
    {
      printf("The number is odd");
      z=x*y;
      printf("The mul is:%d\n",z);
    }


  return 0;
}
