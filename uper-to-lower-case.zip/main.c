#include<stdio.h>
int main ()
{
  char sujon;
  printf ("Enter Your upercase Later: ");
  scanf ("%c", &sujon);
  printf ("Youer lowercase is : %c", sujon + 32);
  return 0;

}
