#include<stdio.h>
 int sujon(int s)
 {
     while(s>9)
     {
         s=s/10;
     }
     return s;
 }
 int z(int s)
 {
     int r=s%10, m=0;
     s=s/10;
     while(s!=0)
 
 {
    int le=s%10; 
    s=s/10;
    if(r%2==le%2)
    {
       m=1;
      break; 
    }
    r=le;
 }
 
 return m;
 }
  int main()
  {
      int s;
      printf("Enter a number=");
      scanf("%d",&s);
      int a=s/10;
      int q=sujon(s);
      int n=s%10;
      int ok=0;
      while(a>=10)
      {
          int le=a%10;
          a=a/10;
          if(le>q && le>n)
          {
              ok=1;
              break;
          }
      }
     int result=z(s);
     if(result==1)
     {
         printf("Not Opaque Number\n");
     }
      else
      {
          if(ok==1)
          printf("Opaque Number\n");
         else
          printf("Not Opaque Number\n");
      }
      return 0;
  }
 
